<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="/public/assets/images/icons/ico.ico" type="image/x-icon">
</head>
<body>
    <?php include 'public/pages/login.php'; ?>
</body>
</html>