<?php
return [
    'client_id' => 'AdKIMo4pfQ_z4QD24wosQfk_TqH8TVXKWgMZ1h77OzcL1fG9_3nMoxhR9uwy6AXzDIhnpyC8RFfuiDkh',
    'client_secret' => 'EEbrRiJFIftW79k1sdc6YTcwMEFdD-QAejF-7VUjaQXWvnkEY8SDf81TQmp5UGG3BT-Uq031m7iwXx_l'
];
