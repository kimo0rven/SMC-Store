<?php
$title = "Michaelite Store";
$favicon = "/public/assets/images/icons/ico.ico";
?>